# 2tasty

MyFood was renamed to 2tasty

## What it does ##

With this extension you can add simply a recipe from a homepage to the 2tasty Instance.

## Versions
Version 0.2:
Settings page for the base url
